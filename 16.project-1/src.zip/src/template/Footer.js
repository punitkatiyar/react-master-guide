import React from 'react'

function Footer() {
  return (
    <div className='footer'>
      <h4>Copyright &copy; 2023</h4>
    </div>
  )
}

export default Footer