import Footer from "./template/Footer";
import Header from "./template/Header";

import Home from "./template/Home";

function App() {
  return (
    <>
      <Header/>
      <Home />
      <Footer/>
    </>
  );
}
export default App;
